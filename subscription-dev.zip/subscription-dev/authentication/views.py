# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.shortcuts import render
from app.models import UniqueUrl
# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.forms.utils import ErrorList
from django.http import HttpResponse
from .forms import LoginForm, SignUpForm, PhoneNumberForm, OTPForm
import base64
from django.conf import settings
from app.models import Phone, OTPHAsh
import pyotp
from twilio.rest import Client
from utils import send_otp_mail
import random
import string

TWILIO_ACCOUNT_SID = settings.TWILIO_ACCOUNT_SID
TWILIO_AUTH_TOKEN = settings.TWILIO_AUTH_TOKEN

def login_view(request):
    form = LoginForm(request.POST or None)
    msg = None

    if request.method == "POST":

        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                # login(request, user)
                return redirect("verify_otp", user_id=user.id)
            else:    
                msg = 'Invalid credentials'    
        else:
            msg = 'Error validating the form'    

    return render(request, "accounts/login.html", {"form": form, "msg" : msg})

def generate_otp(user, random_string):
    phone = Phone.objects.filter(user=user)
    if phone.exists():
        user_phone = phone.first()
        phone_number = user_phone.mobile
        secret_key = phone_number + settings.SECRET_KEY + random_string
        key = base64.b32encode(secret_key.encode())
        OTP = pyotp.HOTP(key)
        otp = OTP.at(0)
    else:
        secret_key = user.email + settings.SECRET_KEY + random_string
        key = base64.b32encode(secret_key.encode())
        OTP = pyotp.HOTP(key)
        otp = OTP.at(0)
    return otp

def otp_view(request, *args, **kwargs):
    form = OTPForm(request.POST or None)
    user_id = kwargs['user_id']
    user = User.objects.get(id=user_id)
    if request.method=="POST":
        otp_hash = OTPHAsh.objects.filter(user=user)
        if otp_hash.exists():
            hash = otp_hash.first().hash
            if form.is_valid():
                form_otp = int(form.cleaned_data.get("otp"))
                otp = generate_otp(user, hash)
                if int(form_otp)==int(otp):
                    login(request, user)
                    return redirect("/")
                else:
                    return redirect("verify_otp", user_id=kwargs["user_id"])
        else:
            return redirect("verify_otp", user_id=kwargs["user_id"])
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    otp_hash = OTPHAsh.objects.update_or_create(
        user=user,defaults={'hash': random_string},
    )
    otp = generate_otp(user, random_string)

    # if phone.exists():      
    #     twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    #     message = twilio_client.messages.create(body="Your OTP is" + otp, from_="+12065370116", to=phone.first().mobile)
    send_otp_mail(user.username, user.email, otp)
    return render(request, "accounts/otp.html", {"form": form})

def register_user(request):

    msg     = None
    success = False

    if request.method == "POST":
        form = SignUpForm(request.POST)
        phone_form = PhoneNumberForm(request.POST)
        if form.is_valid() and phone_form.is_valid():
            form.save()
            phone = phone_form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            user = authenticate(username=username, password=raw_password)
            phone.user = user
            phone.save()
            msg     = 'User created.'
            success = True
            
            #return redirect("/login/")

        else:
            msg = 'Form is not valid'    
    else:
        form = SignUpForm()
        phone_form = PhoneNumberForm()
    return render(request, "accounts/register.html", {"form": form, "msg" : msg, "phone_form": phone_form, "success" : success })

def authenticate_view(request, *args, **kwargs):
    if request.method=="GET":
        uri = kwargs['uri']
        uri_objects = UniqueUrl.objects.filter(url=uri)
        if uri_objects.exists():
            uri_object = uri_objects.first()
            uri_object.is_authenticated = True
            uri_object.save()
            user = uri_object.user
            if user:
                login(request, user)
                return redirect("/")
        else:
            return redirect('register')
