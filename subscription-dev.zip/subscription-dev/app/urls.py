# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.urls import path, re_path
from app import views

urlpatterns = [
    # Matches any html file 
    re_path(r'^.*\.html', views.pages, name='pages'),

    # The home page
    path('', views.index, name='home'),
    path("create-sub", views.create_sub, name="create sub"),
	path("complete", views.complete, name="complete"),
    path('plans/', views.checkout, name="subscribe"),
    # path('plans/checkout/session', views.checkoutSession, name="checkout_session"),
    path('webhook/', views.webhook, name="webhook"),
    path('validate/', views.validate_message, name="validate-message")
]
