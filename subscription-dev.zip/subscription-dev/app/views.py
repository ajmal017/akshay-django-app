# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.template import loader
from django.http import HttpResponse, JsonResponse
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django import template
from django.contrib.auth.models import User
import os
import json
import stripe
import djstripe
import threading
from djstripe.models import Product, Subscription
from helpdesk.models import Ticket
from .models import *
from core.settings import STRIPE_SECRET_KEY
import datetime
import pytz
from .decorators import authentication_required
from utils import send_subscription_mail
from .models import UniqueUrl, Webhook 
from .signals import create_user_url
from django.contrib.auth.models import User

def validate_message(request):
    if request.method=="POST":
        user = request.user
        create_user_url(User, user)
    return render(request, 'accounts/validate_message.html')

@login_required(login_url="/login/")
# @authentication_required
def index(request):
    tickets = Ticket.objects.all()
    time_24_hours_ago = datetime.datetime.now(tz=pytz.utc) - datetime.timedelta(hours=24)
    total_new_users = User.objects.filter(date_joined__gte=time_24_hours_ago).count()
    total_new_subscribers = Subscription.objects.filter(start_date__gte=time_24_hours_ago).count()
    active_users = User.objects.filter(is_active=True).count()
    return render(
        request, 
        "index.html", 
        {"tickets":tickets, 'new_users': total_new_users, 'new_subscribers': total_new_subscribers, "active_users": active_users}
    )

@login_required(login_url="/login/")
@authentication_required
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:
        
        load_template = request.path.split('/')[-1]
        html_template = loader.get_template( load_template )
        return HttpResponse(html_template.render(context, request))
        
    except template.TemplateDoesNotExist:

        html_template = loader.get_template( 'error-404.html' )
        return HttpResponse(html_template.render(context, request))

    except:
    
        html_template = loader.get_template( 'error-500.html' )
        return HttpResponse(html_template.render(context, request))


@login_required(login_url="/login/")
# @authentication_required
def checkout(request):
    if request.method=="GET":
        products = Product.objects.all()
        return render(request, 'payments/checkout.html', {'products':products})


@login_required(login_url="/login/")
# @authentication_required
@csrf_exempt
def create_sub(request):
    if request.method == 'POST':
        # Reads application/json and returns a response
        data = json.loads(request.body)
        payment_method = data['payment_method']
        stripe.api_key = STRIPE_SECRET_KEY
        payment_method_obj = stripe.PaymentMethod.retrieve(payment_method)
        djstripe.models.PaymentMethod.sync_from_stripe_data(payment_method_obj)

        try:
            # This creates a new Customer and attaches the PaymentMethod in one API call.
            customer = stripe.Customer.create(
                payment_method=payment_method,
                email=request.user.email,
                invoice_settings={
                    'default_payment_method': payment_method
                },
                # It is mandatory for some countries to send address and name for outbound transactions
                address={
                    'line1': "line1", # Add first line of adress
                    'city': "city", # Add city
                    'country': "IN", # Country code
                    'line2': "line2", # Add line 2
                    'postal_code': "postal_code", # Add postal Code
                    'state': "state" # Add state
                },
                name=request.user.first_name + " " + request.user.last_name

            )

            djstripe_customer = djstripe.models.Customer.sync_from_stripe_data(customer)
            request.user.customer = djstripe_customer
           

            # At this point, associate the ID of the Customer object with your
            # own internal representation of a customer, if you have one.
            # print(customer)

            # Subscribe the user to the subscription created
            subscription = stripe.Subscription.create(
                customer=customer.id,
                items=[
                    {
                        "price": data["price_id"],
                    },
                ],
                expand=["latest_invoice.payment_intent"]
            )

            djstripe_subscription = djstripe.models.Subscription.sync_from_stripe_data(subscription)

            request.user.subscription = djstripe_subscription
            request.user.save()
            send_subscription_mail(request.user.username, request.user.email, djstripe_subscription.plan.product.name)
            return JsonResponse(subscription)
        except Exception as e:
            return JsonResponse({'error': (e.args[0])}, status =403)
    else:
        return HTTPresponse('requet method not allowed')

@login_required
# @authentication_required
def complete(request):
    return render(request, "payments/complete.html")


# @login_required(login_url="/login/")
# def checkoutSession(request):
#     if request.method=="POST":
#         try:
#             plan_id = int(request.POST.get('plan-id'))
#             plan = Plan.objects.get(id=plan_id)
#             checkout_session = stripe.checkout.Session.create(
#                 payment_method_types=['card'],
#                 line_items=[
#                     {
#                         'price_data': {
#                             'currency': 'usd',
#                             'unit_amount': int((plan.price) * 100),
#                             'product_data': {
#                                 'name': plan.name,
#                                 # Here when in production as all the images will be stored in one isolated environmen, say S#, we can
#                                 # pass S# link
#                                 'images': ['https://i.imgur.com/EHyR2nP.png'],
#                             },
#                         },
#                         'quantity': 1,
#                     },  
#                 ],
#                 mode='payment',
#                 success_url="http://" + request.get_host() + reverse('home'),
#                 cancel_url="http://" + request.get_host() + reverse('home'),
#             )
#             session_data = {'id':checkout_session.id}
#             return JsonResponse(session_data, safe=False)
#         except Exception as e:
#             session_data = {'id':""}
#             return JsonResponse(session_data, safe=False)


@require_POST
@csrf_exempt
def webhook(request):
    jsondata = request.body
    data = json.loads(jsondata)
    user_uri = data['uri']
    hash = data['hash']
    message = data["data"]
    print(threading.current_thread().ident)
    Webhook.objects.create(message=message, thread_id=str(threading.current_thread().ident))
    # if UniqueUrl.is_valid(hash, user_uri):
    #     message = data["data"]
    #     Webhook.objects.create(message=message, thread_id=threading.currentThread())
    #     print("Valid")
    #     # Do things
    # else:
    #     print("Invalid")
    return HttpResponse()
