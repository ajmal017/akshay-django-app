from .models import UniqueUrl
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect

def authentication_required(function):
    def is_authenticated(request, *args, **kwargs):
        user = request.user
        uri_objects = UniqueUrl.objects.filter(user=user)
        if uri_objects.exists():
            uri_object = uri_objects.first()
            if uri_object.is_authenticated:
                return function(request, *args, **kwargs)
            else:
                return redirect('validate-message')
        else:
            return redirect('validate-message')
    is_authenticated.__doc__=function.__doc__
    is_authenticated.__name__=function.__name__
    return is_authenticated
