from django import template
import string

register = template.Library()

@register.filter
def humanize_user(user):
    if user:
        return user.first_name + " " + user.last_name 
    else:
        return None

@register.filter
def get_icon(user):
    if user:
        return string.capwords(user.first_name[0])
    else:
        return ""


@register.filter
def get_status(ticket):
    return ticket._get_status()