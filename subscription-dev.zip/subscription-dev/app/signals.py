from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import UniqueUrl
from datetime import timedelta, date
# from django.core.mail import EmailMultiAlternatives
# from django.template.loader import get_template
# from django.conf import settings
from utils import send_mail

@receiver(post_save, sender=User)
def create_user_url(sender, instance, **kwargs):
    print("signal")
    # create unique url
    try:
        uri_object = UniqueUrl.objects.get(user=instance)
    except UniqueUrl.DoesNotExist:
        expiration_date = date.today() + timedelta(days=10)
        unique_url_object = UniqueUrl.objects.create(user=instance, expiration_date=expiration_date)
        hash, uri = unique_url_object.encode_url()
        send_mail(uri, instance)