# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
import hashlib
import zlib
import urllib
import pickle
import base64 

# Create your models here.
class UniqueUrl(models.Model):
    url = models.CharField(max_length=1000)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    expiration_date = models.DateField()
    url_hash = models.CharField(max_length=200)
    is_authenticated = models.BooleanField(blank=True, null=True)
    
    def __str__(self):
        return self.user.username
    
    def encode_url(self):
        data = [str(self.user.username),
                str(self.expiration_date),
                str(self.user.id)]
        my_url = base64.b64encode(zlib.compress(pickle.dumps(data,0))).decode('utf-8')
        my_hash = hashlib.md5((settings.UNIQUE_HASH_CODE + my_url).encode('utf-8')).hexdigest()[:12]
        self.url = my_url
        self.url_hash = my_hash
        self.save()
        return my_hash, my_url
    
    @classmethod
    def is_valid(cls, hash, url):
        m = hashlib.md5((settings.UNIQUE_HASH_CODE + url).encode('utf-8')).hexdigest()[:12]
        if m != hash:
            return False
        return True

class OTPHAsh(models.Model):
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE)
    hash = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.user.username

class Phone(models.Model):
    mobile = models.CharField(max_length=10, blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    hash = models.CharField(blank=True, null=True, max_length=50)
    
    def __str__(self):
        return self.user.username


class Plan(models.Model):
    name = models.CharField(max_length=50)
    price = models.FloatField(null=True, blank=True)
    
    def __str__(self):
        return self.name


class Webhook(models.Model):
    message = models.CharField(max_length=150, blank=True, null=True)
    entry_time = models.DateTimeField(
        blank=True, null=True, auto_now_add=True
    )
    thread_id = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.message
