from django.contrib.auth.models import User
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.conf import settings

def send_mail(uri, user):
    plaintext = get_template('email-template/email.txt')
    htmly     = get_template('email-template/email.html')

    d = { 'username': user.username,'login_link': 'http://127.0.0.1:8000/login/'}

    subject, from_email, to = 'Welcome', settings.EMAIL_HOST_USER, user.email
    text_content = plaintext.render(d)
    html_content = htmly.render(d)
    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
    msg.attach_alternative(html_content, "text/html")
    msg.send()

def send_subscription_mail(username, user_email, plan):
    plaintext = get_template('email-template/subscription_email.txt')
    htmly     = get_template('email-template/subscription_email.html')

    d = { 'username': username,'plan': plan}

    subject, from_email, to = 'Subscription Confirmation', settings.EMAIL_HOST_USER, user_email
    text_content = plaintext.render(d)
    html_content = htmly.render(d)
    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
    msg.attach_alternative(html_content, "text/html")
    msg.send()

def send_otp_mail(username, user_email, OTP):
    plaintext = get_template('email-template/otp_email.txt')
    htmly     = get_template('email-template/otp_email.html')

    d = { 'username': username,'otp': OTP}

    subject, from_email, to = 'OTP', settings.EMAIL_HOST_USER, user_email
    text_content = plaintext.render(d)
    html_content = htmly.render(d)
    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
    msg.attach_alternative(html_content, "text/html")
    msg.send()